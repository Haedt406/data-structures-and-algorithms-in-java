/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package threadextensionexample;

/**
 *
 * @author Hunter
 */
public class ThreadExtensionExample extends Thread{
    public static boolean flag = true;
    
    public void run()
    {
        while(flag)
        {    System.out.println(Thread.currentThread().getId());
             
        }
    }
    //public static void setFlag(boolean x){flag = x;}
    
    public static void main(String [] args)
    {
        ThreadExtensionExample tee= new ThreadExtensionExample();
        for(int i = 0; i< 8; i++){
            tee = new ThreadExtensionExample();
            tee.start();
            
        }
        System.out.println("Goodbye");
        tee.flag = false;
    }
}
