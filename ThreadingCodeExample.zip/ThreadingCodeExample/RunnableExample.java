/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package runnableexample;

/**
 *
 * @author Hunter
 */
public class RunnableExample implements Runnable {

   public void run()
    {
        for(int i = 0; i<4; i++)
        {    System.out.println(Thread.currentThread().getId());
             try{
                Thread.sleep(1000);
            }catch(Exception e)
            {}
        }
    }
    public static void main(String[] args) {
        for (int i = 0; i<8; i++)
        {
            RunnableExample re = new RunnableExample();
            Thread x = new Thread(re);
            x.start();
        }
    }
    
}
