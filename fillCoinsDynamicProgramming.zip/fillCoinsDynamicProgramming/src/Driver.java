/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author hunterl
 */

import java.io.FileNotFoundException;

public class Driver
{
    public static void main (String [] args) throws FileNotFoundException
    {
        Change coins = new Change ("coins.in");
        coins.initialize();
        coins.fillTable();
        coins.solveProblems();
    }
}
