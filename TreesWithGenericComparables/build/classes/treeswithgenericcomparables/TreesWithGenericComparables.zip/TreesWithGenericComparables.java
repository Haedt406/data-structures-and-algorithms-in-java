/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package treeswithgenericcomparables;

/**
 *
 * @author Benjamin Haedt
 */
public class TreesWithGenericComparables {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Dog dog1 = new Dog("dachshund", "black", "d");
        Dog dog2 = new Dog("dachshund", "black", "a");
//        System.out.println(dog1.toString());
//        System.out.println(dog2.toString());
//        System.out.println(dog1.compareTo(dog2));
//        System.out.println(dog2.compareTo(dog1));
        Dog dog3 = new Dog("dachshund", "black", "f");
        //Dog dog4 = new Dog("dachshund", "black", "h");
//        System.out.println(dog3.compareTo(dog4));
//        System.out.println(dog1.compareTo(dog3));
//        System.out.println(dog3.compareTo(dog1));
        TreeMaster ourTree = new TreeMaster();
        Node dog1N = new Node(dog1);
        Node dog2N = new Node(dog2);
        Node dog3N = new Node(dog3);
        //Node dog4N = new Node(dog4);
        ourTree.add(dog1N, dog1N);
        ourTree.add(dog1N, dog2N);
        ourTree.add(dog1N, dog3N);
        //ourTree.add(dog1N, dog4N);
       // ourTree.postOrder(dog1N);
        Node dog5N = new Node(new Dog("dachshund", "black", "1"));
        ourTree.add(dog1N, dog5N);
        Node dog6N = new Node(new Dog("dachshund", "black", "b"));
        ourTree.add(dog1N, dog6N);
        System.out.println("Post Order: ");
        ourTree.postOrder(dog1N);
        System.out.println(" ");
        System.out.println("Pre Order: ");
        ourTree.preOrder(dog1N);
        System.out.println(" ");
        System.out.println("In Order: ");
        ourTree.inOrder(dog1N);
        System.out.println(" ");
        ourTree.delete(dog1N, dog2N);
        System.out.println(" ");
        System.out.println("In Order: ");
        ourTree.inOrder(dog1N);
        System.out.println(" ");
        ourTree.delete(dog1N, dog5N);
        System.out.println(" ");
        System.out.println("In Order: ");
        ourTree.inOrder(dog1N);
        System.out.println(" ");
        ourTree.delete(dog1N, dog3N);
        System.out.println(" ");
        System.out.println("In Order: ");
        ourTree.inOrder(dog1N);
        System.out.println(" ");
        ourTree.delete(dog1N, dog6N);
        System.out.println(" ");
        System.out.println("In Order: ");
        ourTree.inOrder(dog1N);
        ourTree.delete(dog1N, dog1N);
        System.out.println(" ");
        System.out.println("In Order: ");
        ourTree.inOrder(dog1N);
       // System.out.println(ourTree.root.getData());
        
    }
    
}
